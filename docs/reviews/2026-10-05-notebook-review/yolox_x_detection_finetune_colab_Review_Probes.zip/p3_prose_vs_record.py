"""P3: compare specific claims in the notebook prose about *this* model with the repository's own measurements
of YOLOX-X in docs/release-verification.md and MODEL_CARD.md. Each check quotes the notebook sentence and the
record sentence it disagrees with (text search only; nothing is executed)."""
import json, re, sys
from pathlib import Path
repo, out = Path(sys.argv[1]), sys.argv[2]
nb = json.loads((repo / 'tutorials/yolox_x_detection_finetune_colab.ipynb').read_text())
cells = {i: ''.join(c['source']) for i, c in enumerate(nb['cells']) if c['cell_type'] == 'markdown'}
rec = (repo / 'docs/release-verification.md').read_text(); card = (repo / 'MODEL_CARD.md').read_text()
def quote(text, key, w=160):
    j = text.find(key); return None if j < 0 else re.sub(r'\s+', ' ', text[max(0, j - w // 2): j + w])
def find(key):
    return [(i, quote(s, key)) for i, s in cells.items() if key in s]
res = {
 'football_alternatives': {'notebook': find('offers `kite`'), 'record': quote(rec, 'S proposes `kite`', 260), 'model_card': quote(card, 'unlike the sibling YOLOX-S', 260)},
 'unfreeze_collapse': {'notebook': find('collaps'), 'record': quote(rec, 'unfrozen-collapse warning', 300)},
 'coco_iou_range': {'notebook': find('0.91–0.96'), 'record_iou': re.findall(r'COCO IoU ([0-9./]+)', rec)},
 'baseline_claim': {'notebook': find('baseline is not zero'), 'record_baseline': re.findall(r'baseline AP ([0-9.]+) / AP50 ([0-9.]+)', rec)},
}
iou = [float(x) for x in res['coco_iou_range']['record_iou'][0].split('/') if float(x) > 0]
res['coco_iou_range']['record_nonzero_min_max'] = [min(iou), max(iou)]
print(json.dumps(res, indent=1, ensure_ascii=False)); json.dump(res, open(out, 'w'), indent=1, ensure_ascii=False)
