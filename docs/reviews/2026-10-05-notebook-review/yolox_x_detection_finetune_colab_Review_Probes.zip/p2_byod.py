"""P2: cell 45's two BYOD branches exec'd as shipped, with each flag set to True and nothing else edited (the only
interaction the notebook asks for), up to the first model call; the dataset branch has no upload or path input and
starts from `byod_records = []`. Also the image branch with a google.colab stand-in (one image, a cancelled
dialog) and outside Colab."""
import io, json, sys, types, importlib, contextlib
from pathlib import Path
import numpy as np
from PIL import Image
repo, out = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
pkg = types.ModuleType('yolox_x_detection_pipeline'); pkg.__path__ = [str(repo / 'src/yolox_x_detection_pipeline')]
sys.modules['yolox_x_detection_pipeline'] = pkg
S = importlib.import_module('yolox_x_detection_pipeline.samples')
P = importlib.import_module('yolox_x_detection_pipeline.pipeline')
nb = json.loads((repo / 'tutorials/yolox_x_detection_finetune_colab.ipynb').read_text())
c45 = next(''.join(c['source']) for c in nb['cells'] if c['cell_type'] == 'code' and 'USE_BYOD_DATASET = False' in ''.join(c['source']))
ds = '\n'.join(l[4:] for l in c45.split('if USE_BYOD_DATASET:\n', 1)[1].split('    byod_train,', 1)[0].splitlines())
img = '\n'.join(l[4:] for l in c45.split('if USE_BYOD_IMAGE:\n', 1)[1].split('    byod_result = ', 1)[0].splitlines())
g0 = lambda: {'validate_dataset': P.validate_dataset, 'validate_inputs': P.validate_inputs, 'EPOCHS': 6, 'json': json, 'io': io, 'Image': Image,
              'BYOD_CLASS_NAMES': ['my-class-a', 'my-class-b'], 'threshold': 0.3, 'nms_threshold': 0.3}
res = {'dataset_branch_source_has_input_mechanism': any(k in ds for k in ('upload', 'BYOD_PATH', 'BYOD_DATASET_DIR', 'read_')),
       'dataset_branch_first_lines': ds.strip().splitlines()[:3]}
try:
    with contextlib.redirect_stdout(io.StringIO()):
        exec(ds, g0())
    res['dataset_branch_as_shipped'] = 'accepted'
except BaseException as exc:
    res['dataset_branch_as_shipped'] = f'{type(exc).__name__}: {exc}'[:200]
def run_img(uploaded):
    colab = types.ModuleType('google.colab'); colab.files = types.SimpleNamespace(upload=lambda: dict(uploaded))
    sys.modules['google'] = types.ModuleType('google'); sys.modules['google.colab'] = colab
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            g = g0(); exec(img, g)
        return {'outcome': 'accepted', 'size': list(g['byod_image'].size)}
    except BaseException as exc:
        return {'outcome': 'refused', 'error': f'{type(exc).__name__}: {exc}'[:200]}
b = io.BytesIO(); Image.fromarray(np.zeros((100, 120, 3), dtype=np.uint8)).save(b, 'PNG')
res['image_one_png'] = run_img({'a.png': b.getvalue()})
res['image_text_file'] = run_img({'a.png': b'not an image'})
res['image_cancelled'] = run_img({})
for k in ('google', 'google.colab'): sys.modules.pop(k, None)
try:
    exec('from google.colab import files', {}); res['outside_colab'] = 'no error'
except Exception as exc:
    res['outside_colab'] = f'{type(exc).__name__}: {exc}'
res['image_branch_has_path_field'] = 'BYOD_IMAGE_PATH' in c45
print(json.dumps(res, indent=1)); (out / 'p2.json').write_text(json.dumps(res, indent=1))
