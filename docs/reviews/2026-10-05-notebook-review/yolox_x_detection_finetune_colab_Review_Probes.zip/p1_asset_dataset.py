"""P1: (a) download the pinned release asset yolox_x.pth from the upstream GitHub release tag 0.1.1rc0 and check
its byte size and SHA-256 against the notebook's inline MANIFEST (the file is hashed, never unpickled);
(b) rebuild the 40-image sign dataset (seed 0) and the seeded holdout split with the carried samples / pipeline
helpers and validate it, to compare with the recorded counts."""
import hashlib, json, sys, types, importlib, urllib.request
from collections import Counter
from pathlib import Path
repo, out = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
nb = json.loads((repo / 'tutorials/yolox_x_detection_finetune_colab.ipynb').read_text())
cell = next(''.join(c['source']) for c in nb['cells'] if c['cell_type'] == 'code' and 'MANIFEST = {' in ''.join(c['source']))
manifest = json.loads(cell.split('MANIFEST = ', 1)[1].split('\n\nif ', 1)[0])
entry = manifest['files'][0]
h, n = hashlib.sha256(), 0
with urllib.request.urlopen(manifest['sourceUrl'], timeout=120) as r:
    while True:
        b = r.read(1 << 20)
        if not b: break
        h.update(b); n += len(b)
res = {'asset': {'url': manifest['sourceUrl'], 'bytes': n, 'sha256': h.hexdigest(), 'manifest_bytes': entry['bytes'], 'manifest_sha256': entry['sha256'],
                 'match': n == entry['bytes'] and h.hexdigest() == entry['sha256']}}
pkg = types.ModuleType('yolox_x_detection_pipeline'); pkg.__path__ = [str(repo / 'src/yolox_x_detection_pipeline')]
sys.modules['yolox_x_detection_pipeline'] = pkg
S = importlib.import_module('yolox_x_detection_pipeline.samples')
try:
    P = importlib.import_module('yolox_x_detection_pipeline.pipeline')
    recs = S.sign_dataset(40, seed=0)
    man = P.validate_dataset(recs, S.SIGN_CLASSES, epochs=6)
    tr, ho = P.split_records(recs, holdout=0.25, seed=0)
    res['dataset'] = {'n_records': man.get('n_records'), 'n_boxes': man.get('n_boxes'), 'boxes_per_class': man.get('boxes_per_class'), 'findings': man.get('findings'),
                      'split': [len(tr), len(ho)], 'held_out_boxes': sum(len(r['boxes']) for r in ho), 'held_out_per_class': dict(Counter(l for r in ho for l in r['labels']))}
except ImportError as exc:
    res['dataset'] = f'pipeline import needs: {exc}'
print(json.dumps(res, indent=1)); (out / 'p1.json').write_text(json.dumps(res, indent=1))
