"""Static journey/hygiene scan of a notebook (no execution). Reports, per cell index, the patterns
the review framework asks about: in-kernel installs and restart guards, upload dialogs, unguarded
iterator access, quality asserts, placeholders, warning suppression, guided-layer markers and
infrastructure labelling."""
import json, re, sys
nb = json.load(open(sys.argv[1]))
cells = nb['cells']
pat = {
  'in_kernel_pip': r"pip['\"]?,?\s*['\"]?install|%pip install|!pip install|-m', 'pip'",
  'uv_venv': r"\buv\b.*venv|uv venv|'venv'|require-hashes",
  'restart_instruction': r"[Rr]estart the runtime|restart the kernel|Restart runtime",
  'files_upload': r"files\.upload\(",
  'google_colab_import': r"from google\.colab|import google\.colab",
  'next_iter': r"next\(iter\(",
  'assert_stmt': r"^\s*assert ",
  'placeholder_code': r"TODO|TBD|FIXME|WRITE ME",
  'filterwarnings_ignore': r"filterwarnings\(['\"]ignore",
  'set_seed': r"manual_seed|set_seed|default_rng\(|random\.seed|np\.random\.seed",
  'trust_remote_code_true': r"trust_remote_code\s*=\s*True",
}
guided = {
  'audience': r"[Ii]ntended (learner|audience)|[Ww]ho (this|the) notebook is for|[Aa]udience",
  'how_to_use': r"[Hh]ow to use this notebook",
  'roadmap': r"[Rr]oadmap",
  'glossary': r"[Gg]lossary",
  'prediction': r"[Pp]redict(ion)? (first|before)|[Mm]ake a prediction|Predict:|\*\*Predict",
  'what_to_notice': r"[Ww]hat to notice|[Ee]xpected result",
  'checkpoint': r"[Cc]heck your (reasoning|understanding)|[Ii]nterpretation checkpoint|[*][*]Checkpoint",
  'details_block': r"<details",
  'troubleshooting': r"[Tt]roubleshooting",
  'conclusion_template': r"[Cc]onclusion (template|scaffold)|[Ww]rite (your|a) conclusion",
  'infrastructure_label': r"Infrastructure",
  'look_for': r"[Ll]ook for",
  'change_one_thing': r"[Cc]hange one thing",
}
out = {'n_cells': len(cells), 'n_code': sum(c['cell_type'] == 'code' for c in cells),
       'n_markdown': sum(c['cell_type'] == 'markdown' for c in cells),
       'cells_with_outputs': [i for i, c in enumerate(cells) if c['cell_type'] == 'code' and c.get('outputs')],
       'cellView_form': [i for i, c in enumerate(cells) if c.get('metadata', {}).get('cellView') == 'form'],
       'metadata_dimer': nb['metadata'].get('dimer'), 'hazards': {}, 'guided_layer': {}}
for k, p in pat.items():
    hits = [i for i, c in enumerate(cells) if re.search(p, ''.join(c['source']), re.M)]
    if hits: out['hazards'][k] = hits
out['hazards']['placeholder_markdown'] = [i for i, c in enumerate(cells) if c['cell_type'] == 'markdown' and re.search(r"\{[A-Z_]{3,}\}|\{\{|@[A-Z]+:[A-Z_0-9]+@|TODO|TBD|FIXME|WRITE ME", ''.join(c['source']))]
for k, p in guided.items():
    out['guided_layer'][k] = [i for i, c in enumerate(cells) if c['cell_type'] == 'markdown' and re.search(p, ''.join(c['source']))]
print(json.dumps(out, indent=1, default=str)[:6000])
if len(sys.argv) > 2: json.dump(out, open(sys.argv[2], 'w'), indent=1, default=str)
